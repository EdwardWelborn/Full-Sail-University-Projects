﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace welborn_edward_debugging
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

/* Notes on debugging
 * 
 * syntax - the grammer or language of the code.
 * --  such as lack of ; or () are common errors
 * -- could also be casing on the variables
 * logic - logical ordering of the commands.
 * -- using < instead of > is a common problem
 * 
 * debug.writeline, display to output window
 * 
 * breakpoints are very valuable in finding logic errors and the debug writelin in the output window
 */
