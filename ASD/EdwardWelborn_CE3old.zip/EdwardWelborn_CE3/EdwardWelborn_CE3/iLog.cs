﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdwardWelborn_CE3
{
    interface iLog
    {
        void Log(string logsIt);
        void LogD(string logsIt);
        void LogW(string logIt);

    }
    
}
