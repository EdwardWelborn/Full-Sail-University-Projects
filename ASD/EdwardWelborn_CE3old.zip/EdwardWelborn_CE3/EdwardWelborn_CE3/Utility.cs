﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdwardWelborn_CE3
{
    class Utility
    {
        public Utility()
        {

        }
        public static void PressAnyKey()
        {
            Console.WriteLine("\r\nPress Any Key to Continue: ");
            Console.ReadKey();
        }
    }
 

}
