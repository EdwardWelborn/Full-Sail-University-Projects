﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Program
    {
        List<Animal> Pets = new List<Animal>();
        static void Main(string[] args)
        {
        }
        static void Welcome(List<Animal> Pets )
        {
            string sWelcome = string.Empty;

            sWelcome = Validation.GetName("Please Enter Your Name: ");
            Pets.Add(new Armadillo);
            Pets.Add(new Chinchilla);
            Pets.Add(new Eagle);
            Pets.Add(new Rabbit);
            Pets.Add(new Fox);
            Pets.Add(new Otter);
           

        }

    }
}
/* Animal Classes:

You will need to implement at least 6 animal classes all should inherit from the Animal base class.

The constructors will need to initialize the Species and Trainable properties as well as the _treat field.
An overriding method named MakeNoise that returns a string that describes the animal making noise. Ex: “A gargled roar comes from the alligator.”
Some animals are trainable (dogs, dolphins, even cats) and some aren’t (snakes, fish etc) and your application should reflect that. At least half of the animals should implement the ITrainable interface. This will mean they will be required to implement the properties and methods as described above in the Interface section.

The Perform method should return a string similar to: "After you signaled clapping hands the otter will now perform the 'jump through the hoop' behavior."
The Train method should collect the signal and behavior strings and input them into the Behavior dictionary and return a string such as: "The dolphin learned to slap it’s tail when you point to the sky."
Contain a Behaviors property that will hold the signals and behaviors the given animal can perform based on what the user enters.

*/

/*
 * Zookeeper Application:

Your main program application class should have the following:

A List object which will contain all the animals you create. --
A method which welcomes the user and adds instances of each animal into the List object.
Your application should list the animals you’ve initialized, specify which are trainable, and give the user the option of selecting one.

Upon selecting an animal it will announce which animal was selected and then provide a menu for activities the user can do with the selected animal:


Training:

If the user selects Training, the program should ask the user what behavior they would like to teach the animal and what signal they will associate with the behavior. The program then stores this information and reprints the menu:


Feeding the Animal:

For feeding an animal a treat (this is for all animals, not just the trainable ones) it produces the following result, printing the string produced by the Eat() method in the Animal base class:


Get the animal to perform a behavior:

When signaling the animal, if the animal is trainable, then the program should ask the user for the relevant signal. If the animal is not trainable a message should show to the user: “The animal you selected is not a trainable animal. Please select a different activity or exit to select a different animal.”

If the signal is in the dictionary it should respond. (If it is not a message should be shown “The dolphin does not know this signal. Train it to recognize this signal and associate it with a behavior.” )


Make noise:

When this option is selected the animal should make a noise:

Or the user can select a different animal.

*/