﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Welborn_Edward_CE05
{
    class Validation
    {
        public static string GetName(string sMessage)
        {
            string sInput = null;
            string validCardName = null;
            do
            {
                Console.Write($"\r\n{sMessage} ");
                sInput = Console.ReadLine();
            } while (!(Regex.IsMatch(sInput, @"^[a-zA-Z ]+$")));
            validCardName = sInput;

            return validCardName;
        }
        public static string GetDescription(string sMessage)
        {
            string sInput = null;
            string validCardDescription = null;
            do
            {
                Console.Write($"\r\n{sMessage} ");
                sInput = Console.ReadLine();
            } while (!(Regex.IsMatch(sInput, @"^[a-zA-Z ]+$")));
            validCardDescription = sInput;

            return validCardDescription;
        }
        public static decimal GetValue(string sMessage)
        {
            string sInput = null;
            decimal validCardValue = 0;
            do
            {
                Console.Write($"\r\n{sMessage} ");
                sInput = Console.ReadLine();
            } while (!(decimal.TryParse(sInput, out validCardValue)));
            
            return validCardValue;
        }
    }
}

