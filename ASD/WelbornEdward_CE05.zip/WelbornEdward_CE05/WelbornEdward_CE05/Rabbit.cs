﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Rabbit : Animal
    {
        string _species = "Rabbit";
        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"The rabbit happily crunches away on the {_treat}";

            return noise;
        }
        public Rabbit(string Species, int FoodConsumed, string Treat) : base(Species, FoodConsumed, Treat)
        {

        }
    }
}
