﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Armadillo : Animal
    {
        string _species = "Armadillo";
        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"Armadillos make grunting sounds as it eats the {_treat}";

            return noise;
        }
        public Armadillo(string Species, int FoodConsumed, string Treat) : base (Species, FoodConsumed, Treat) 
        {

        }
    }

}
