﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Fox : Animal
    {
        string _species = "Fox";
        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"Nobody knows what the fox says as it nibbles on the {_treat}";

            return noise;
        }
        public Fox(string Species, int FoodConsumed, string Treat) : base(Species, FoodConsumed, Treat)
        {

        }
    }
}
