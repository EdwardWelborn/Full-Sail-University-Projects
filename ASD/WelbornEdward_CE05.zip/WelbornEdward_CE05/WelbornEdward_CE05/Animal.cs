﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    abstract class Animal
    {
        string _species = string.Empty;
        int _foodConsumed = 0;
        protected string _treat = string.Empty;

        public string Eat(string Species, string Treat)
        {
            string sEating = string.Empty;
            _species = Species;
            _treat = Treat;
            sEating = $"The {_species} ate a {_treat}";
            Console.WriteLine(sEating);
            return sEating;
        }
        virtual public string MakeNoise(string Species, string Noise)
        {
            string noise = string.Empty;

            return noise;
        }
        private Animal()
        {

        }
        public Animal(string Species, int FoodConsumed, string Treat)
        {

        }
    }
 
}
/* Base Abstract Class:

Create a base abstract class named Animal which contains the following properties and fields:

A property named Species. This will hold the animal’s name (i.e. dolphin)
A field named _foodConsumed to keep track of how much food the animal has consumed.
A field named _treat used to store the name of the food this animal likes to eat as a treat. 
(like fish for dolphins, rats for snakes). This will need to be set to protected access since it will be used in subclasses to set the value unique to each animal.

*/
