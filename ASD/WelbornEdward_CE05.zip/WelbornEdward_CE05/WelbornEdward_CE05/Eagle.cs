﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Eagle : Animal
    {
        string _species = "Eagle";
        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"The Eagle make a loud screach after eating the {_treat}";

            return noise;
        }
        public Eagle(string Species, int FoodConsumed, string Treat) : base(Species, FoodConsumed, Treat)
        {

        }
    }
}
