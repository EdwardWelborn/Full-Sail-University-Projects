﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Otter : Animal
    {
        string _species = "Otter";

        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"The otter makes a playful squeek as it nibbles the {_treat}";

            return noise;
        }
        public Otter(string Species, int FoodConsumed, string Treat) : base(Species, FoodConsumed, Treat)
        {

        }
    }
}
