﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WelbornEdward_CE05
{
    class Chinchilla : Animal
    {
        string _species = "Chinchilla";
        public override string MakeNoise(string Species, string _treat)
        {
            string noise = $"The Chinchilla crunches away on the {_treat}";

            return noise;
        }
        public Chinchilla(string Species, int FoodConsumed, string Treat) : base(Species, FoodConsumed, Treat)
    }
}
