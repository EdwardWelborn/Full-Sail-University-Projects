﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace welborn_edward_interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            User user;
            user = new SuperUser("bob", "12345");

            if (user.Login())
            {
                Console.WriteLine($"Welcome - {user.Name}");
            }
            else
                Console.WriteLine("An Error has occured:");

            Utility.PressAnyKey();
        }
    }
}
