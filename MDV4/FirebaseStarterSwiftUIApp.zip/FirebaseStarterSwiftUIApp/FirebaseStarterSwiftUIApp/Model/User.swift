//
//  User.swift
//  FirebaseStarterSwiftUIApp
//
//  Created by Duy Bui on 8/17/20.
//  Copyright © 2020 iOS App Templates. All rights reserved.
//

import Foundation

struct User {
    let id: String
    let email: String
}
