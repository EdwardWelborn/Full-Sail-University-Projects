﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_9A
{
    public class Submission
    {
        public static Student[] enrollment = new Student[0];

        public static Student Test1(string last, string first, int idNo)
        {
            return null;
        }

        public static Student Test2()
        {
            return null;
        }

        public static bool Test3(Student enrolled)
        {
            return false;
        }

        public static bool Test4(int idNumber)
        {
            return false;
        }

        public static Student Test5(int idNumber)
        {
            return null;
        }
    }
}
