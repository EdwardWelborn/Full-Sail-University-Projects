﻿using System;
using System.Text;
using Lab_7A;

namespace FSPG1
{
    public class Submission
    {
        public static StringBuilder Test1(string [] names)
        {
            return null;
        }

        public static object Test2(float x, float y, float radius)
        {
            return null;
        }

        public static object Test3(float x, float y, float radius)
        {
            return null;
        }

        public static object Test4(float x, float y, float radius)
        {
            return null;
        }

        public static object Test5(float x, float y, float radius)
        {
            return null;
        }

        public static int Test6(string str1, string str2, bool ignoreCase)
        {
            return 0;
        }

        public static string Test7(sbyte offset, string message)
        {
            return null;
        }

        public static string Test8(sbyte offset, string message)
        {
            return null;
        }
    }
}
