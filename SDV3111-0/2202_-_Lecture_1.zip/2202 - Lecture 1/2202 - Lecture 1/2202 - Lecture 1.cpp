// 2202 - Lecture 1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

void Print(); // prototype of the function

int main()
{
    // be careful about assigning in an if statement accidentally
   /* int x = 6;
    if (x = 7)
    {
        std::cout << "it is 7" << std::endl;
    }
    std::cout << x << std::endl;*/

    // switch statements - don't forget the break;
   /* int x = 1;
    switch (x)
    {
    case 1:
    {
        int y = 9;
        std::cout << "It is 1" << std::endl;
    }
    case 2:
    {

        std::cout << "It is 2" << std::endl;
    }

    }*/
    //enum Colors{WHITE,RED, BLUE};
    //Colors color = Colors::WHITE;
    //std::cout << color << std::endl; // will just print out integer value
    //// to print out the color we would have to do a switch
    //switch (color)
    //{
    //case Colors::WHITE:
    //{
    //    std::cout << "White ";
    //    break;
    //}
    //case Colors::RED:
    //{
    //    std::cout << "Red ";
    //    break;
    //}
    //}

    //Print();

    // output to the console
    //int x = 10;
    //std::cout << "x= " << x << std::endl;
    //int array[3] = { 0,1,2 };
    //std::cout << array << std::endl; // will print memory address of array

    //char name[6] = "Jason";
    //std::cout << name << std::endl;

    // input to console
    //int x;
    //std::cin >> x;
    //if (std::cin.fail()) // check to see if we got an input error
    //{
    //    std::cin.clear(); // clears any errors in the console
    //    std::cin.ignore(INT_MAX, '\n'); // clears out the console buffer
    //}
    //std::cout << x << std::endl;

    //int y;
    //std::cin >> y;
    //std::cout << y << std::endl;

    //char name[32];
    //std::cin.getline(name, 32);  // get a line with spaces 
    ////name[5] = 'h';
    //std::cout << name << std::endl;

    //char name2[32];
    //std::cin >> name2;
    //std::cout << name2 << std::endl;

    // Lab 1
    //int array[5];
    //int size = sizeof(array)/sizeof(int); // sizeof gives number of bytes
    //std::cout << size;

    // sizeof of integral types;
    //std::cout << INT_MAX << std::endl;

    // random
    /*srand(time(0));
    int x = rand();
    std::cout << x;*/

    int easy = rand() % 10;
    int medium = rand() % 10 + 10;
    std::cout << easy << '\t' << medium;



}

void Print() // implementation of function
{
    std::cout << "Hello World!\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
