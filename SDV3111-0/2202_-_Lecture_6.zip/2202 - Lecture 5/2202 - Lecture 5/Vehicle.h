#pragma once
class Vehicle
{
private:
    char model[32];
protected:
    int year;
public:
    // constructor
    Vehicle();
    // destructor
    ~Vehicle();
    // getters and setters
    void setModel(const char* _model); // prototype of the function
    char* getModel();
    void setYear(int _year);
    int getYear();

    void Print();
};

