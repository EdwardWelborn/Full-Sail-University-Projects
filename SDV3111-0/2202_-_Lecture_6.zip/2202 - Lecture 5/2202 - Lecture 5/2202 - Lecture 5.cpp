// 2202 - Lecture 5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <vector>
#include "Vehicle.h"
#include "Car.h"

void TextOutput(Car& car); // prototype
void TextInput(Car& car);
void BinaryOutput(std::vector<Car>& cars);
void BinaryInput(std::vector<Car>& cars);

int main()
{
    // include memory leak detection
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(-1);
    _CrtDumpMemoryLeaks();

    // text output
    /*Car car;
    car.setModel("Honda");
    car.setYear(2022);*/
    //TextOutput(car);

    // text input
   /* Car car;
    TextInput(car);
    car.Print();*/

    // binary output
   /* std::vector<Car> cars;
    Car car;
    for (int i = 0; i < 10; i++)
    {
        car.setYear(2000 + i);
        cars.push_back(car);
    }
    BinaryOutput(cars);*/

    //binary input
    std::vector<Car> cars;
    BinaryInput(cars);
    for (int i = 0; i < cars.size(); i++)
    {
        cars[i].Print();
    }



}


void TextOutput(Car& car)
{
    // create an instance of fstream
    std::ofstream outputfile;
    // open file
    outputfile.open("output.txt"); // by default this opens in truncate ( overwrties file )
    //outputfile.open("output.txt", std::ios_base::app); //  this opens in append mode ( append to end of file )
    // check to see if file opened
    if (outputfile.is_open())
    {
        // do stuff
        outputfile << car.getModel() << std::endl;
        outputfile << car.getYear() << std::endl;
        outputfile << car.getTires() << std::endl;

        // close the file
        outputfile.close();

    }
    else
    {
        std::cout << "File did not open" << std::endl;
    }

}


void TextInput(Car& car)
{
    std::ifstream inputfile;
    inputfile.open("output.txt");
    if (inputfile.is_open())
    {
        char buffer[32];
        inputfile.getline(buffer, 32 );
        car.setModel(buffer);

        int year;
        inputfile >> year;
        car.setYear(year);

        int tires;
        inputfile >> tires;
        car.setTires(tires);

        inputfile.close();

    }
    else
    {
        std::cout << "File did not open" << std::endl;
    }
}


void BinaryOutput(std::vector<Car>& cars)
{
    std::ofstream binout;
    binout.open("output.bin", std::ios_base::binary); // open file in binary
    if (binout.is_open())
    {
        // write number of cars to the file
        int numcars = cars.size();
        binout.write((char*)&numcars, sizeof(int));
        // write all the car info in one write
        binout.write((char*)&cars[0], sizeof(Car) * cars.size());
        binout.close();
    }
    else
    {
        std::cout << "File did not open" << std::endl;
    }

}


void BinaryInput(std::vector<Car>& cars)
{
    std::ifstream binin;
    binin.open("output.bin", std::ios_base::binary);
    if (binin.is_open())
    {
        // first read the number of cars
        int numcars = 0;
        binin.read((char*)&numcars, sizeof(int));
        // now resize the vector
        cars.resize(numcars);
        // read all the cars from the file
        binin.read((char*)&cars[0], sizeof(Car) * cars.size());
        binin.close();

    }
    else
    {
        std::cout << "File did not open" << std::endl;
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
