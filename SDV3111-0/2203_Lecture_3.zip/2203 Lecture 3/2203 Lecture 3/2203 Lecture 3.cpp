// 2203 Lecture 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Helperr.h"

// struct
struct Person
{
	char name[32];
	int age;
};

void passbyCopy(int x);
void passbyRef(int& _x);
void passbyPtr(int* _x);

void passbyCopy(Person _person);
void passbyRef(Person& _person);
void passbyPtr(Person* _person);

int main()
{
	// variables
	//int x; //0x00cffc2c // 0x007cfed4
	//x = 5;
	//passbyCopy(x);
	//std::cout << x << std::endl;

	// references;
	//int x = 5;		//0x00aff840
	//int& xref = x;	//0x00aff840
	//std::cout << x << '\t' << xref << std::endl;
	//xref = 10;
	//std::cout << x << '\t' << xref << std::endl;
	//passbyRef(x);
	//std::cout << x << '\t' << xref << std::endl;

	//// memory address operator 
	//int x = 5;
	//int* xptr = &x;
	//std::cout << x << '\t' << xptr << std::endl;

	//// dereferene operator
	//int deref = *xptr;
	//std::cout << xptr << '\t' << deref << std::endl;
	//passbyPtr(&x);
	//std::cout << x << std::endl;

	//Person person;
	//person.age = 35;
	//strcpy_s(person.name, "Jason");
	//std::cout << person.name << '\t' << person.age << std::endl;
	//passbyCopy(person);
	//std::cout << person.name << '\t' << person.age << std::endl;
	//passbyRef(person);
	//std::cout << person.name << '\t' << person.age << std::endl;
	//passbyPtr(&person);
	//std::cout << person.name << '\t' << person.age << std::endl;

	Helper::Print();
}

void passbyCopy(int _x) // int _x = x;
{
	_x = _x + 3;
}
void passbyRef(int& _x) // int& _x = x;
{
	_x = _x + 3;
}

void passbyPtr(int* _x)
{
	*_x = *_x + 3;
}


void passbyCopy(Person _person)
{
	_person.age = 20;
	strcpy_s(_person.name, "Tom");
}

void passbyRef(Person& _person)
{
	_person.age = 20;
	strcpy_s(_person.name, "Tom");
}

void passbyPtr(Person* _person)
{
	(*_person).age = 25;
	//_person->age // indirect membership operator - this line is equivalent to above
	strcpy_s((*_person).name, "Fred");
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
