#pragma once
#include <iostream>

namespace Helper
{ 
	void Print()
	{
		std::cout << "Hello" << std::endl;
	}

}