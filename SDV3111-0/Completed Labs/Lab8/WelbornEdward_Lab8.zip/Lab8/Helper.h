﻿#pragma once
#include <iostream>

void CopyString(const char* source, char*& destination);

