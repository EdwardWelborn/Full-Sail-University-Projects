#include "Vehicle.h"
#include <iostream>


Vehicle::Vehicle()
{
	setModel("Model not Set");
	setYear(1);
	//std::cout << "Vehicle constructor" << std::endl;
}


Vehicle::~Vehicle()
{
	// delete nay newed memory
	delete[] model;
	//std::cout << "Vehicle destructor" << std::endl;
}

void Vehicle::setModel(const char* _model) // implementation of the function
{
	// see if model already points to a newed array
	if (model != nullptr)
	{
		delete[] model;
	}
	// first see how many chars we need
	int length = strlen(_model) + 1; // add one for the null terminator
	// new an array of chars to store model in
	model = new char[length];
	// copy from passed in _model to model array
	strcpy_s(model, length, _model);
}


char* Vehicle::getModel()
{
	return model;
}


void Vehicle::setYear(const int _year)
{
	//_year = 8; // _year is const - can't modify
	year = _year;
}

int Vehicle::getYear() const
{
	//year = 5; can not modify const object
	//Print();
	return year;
}


void Vehicle::Print()
{
	std::cout << model << std::endl;
	std::cout << getYear() << std::endl;
}


// assignemnt operator
Vehicle& Vehicle::operator=(const Vehicle& _other)
{
	if (this != &_other) // car1 = car1
	{
		setModel(_other.model); // set name does the deep copy for us
		year = _other.year;
	}

	return *this;
}

// copy constructor
Vehicle::Vehicle(const Vehicle& other)
{
	*this = other;
}

