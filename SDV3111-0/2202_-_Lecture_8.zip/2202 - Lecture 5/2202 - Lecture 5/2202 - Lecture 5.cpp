// 2202 - Lecture 5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <vector>
#include "Vehicle.h"
#include "Car.h"
#include "Plane.h"
#include "Boat.h"

int main()
{
    // include memory leak detection
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(-1);
    _CrtDumpMemoryLeaks();

    //Vehicle vehicle; // can not instatiate ABC
    //Vehicle* vehicleptr; // can have a pointer to an ABC
    //vehicleptr = new Vehicle(); // can not instatiate ABC
    
    //Boat boat; // can not instatiate a Boat - does not have Print() method

    // upcasting ( has purposes ( virtual functions ) )
    //Vehicle* vehicleptr = (Vehicle*)new Car(); 
    ////vehicleptr->setTires(6); // thinks it a pointer to a Vehicle object
    //// so we can't access things from the Car class
    //vehicleptr->Print(); // because Print is virtual in Vehicle it looks to see if Print() exists in derived class

    ////downcasting ( bad )
    //Car* car = (Car*)new Vehicle();
    //// I can now call Car functions - but what happens?
    //car->setTires(6); // we can overwrite memory we don't own.
    //std::cout << car->getTires();

    // dynamic_cast
    //Vehicle* vptr = new Vehicle();
    //Car* cptr = new Car();

    //Vehicle* test1 = dynamic_cast<Vehicle*>(cptr); // upcating - this is safe so returns the pointer
    //if (test1 != nullptr)
    //{
    //    test1->Print();
    //}

    //Car* test2 = dynamic_cast<Car*>(vptr); // downcasting - not safe, returns nullptr
    //if (test2 != nullptr)
    //{
    //    test2->Print();
    //}

    //delete vptr;
    //delete cptr;

    //std::vector<Vehicle*> vehicles;
    //vehicles.push_back(new Plane());
    //vehicles.push_back(new Car());

    //// lets say user wnted to copy vehicles[0]
    //Car* cartest = dynamic_cast<Car*>(vehicles[0]);
    //if (cartest)
    //{
    //    cartest->Print();
    //}
    //Plane* planetest = dynamic_cast<Plane*>(vehicles[0]);
    //if (planetest)
    //{
    //    planetest->Print();
    //}

    //// clean up memory
    //for (int i = 0; i < vehicles.size(); i++)
    //{
    //    delete vehicles[i];
    //}

    Car car;
    //std::cout << car; // << operator not defined for Car
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
