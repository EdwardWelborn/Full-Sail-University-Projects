#pragma once
#include "Vehicle.h"
class Plane : public Vehicle
{
public:
    int wings = 2;

    Plane();
    void Print();
};

