#pragma once
#include "Vehicle.h"
class Boat : public Vehicle
{
};

