#pragma once
class Vehicle
{
private:
    char* model = nullptr;
protected:
    int year;
public:
    // constructor
    Vehicle();
   
    // getters and setters
    void setModel(const char* _model); // prototype of the function
    char* getModel();
    void setYear( const int _year);
    int getYear() const; // invoking object is const

    virtual void Print() = 0; // now a pure virtual function

    // rule of 3
    // assignemnt operator
    Vehicle& operator=(const Vehicle& _other);
    // copy constructor
    Vehicle(const Vehicle& other);
    // destructor
    ~Vehicle();
};

