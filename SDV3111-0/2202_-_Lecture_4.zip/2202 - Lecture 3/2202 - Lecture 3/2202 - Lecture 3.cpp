// 2202 - Lecture 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include "Header.h"


// struct
struct Person
{
    char* name = nullptr;
    int age;
    //void SetName(const char _name[])
    void SetName(const char* _name) // equivalent to above
    {
        // check to see if name already points to a newed array
        if (name != nullptr)
        {
            delete[] name;
        }
        // first figure out how many chars we need
        int length = strlen(_name) + 1; // add one char for null termintor
        // now we can new a array the length we need
        name = new char[length];
        // copy from _name to name 
        strcpy_s(name, length, _name);
    }
};


int main()
{
    // include memory leak detection
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(-1);
    _CrtDumpMemoryLeaks();

    //int x = 10;
    //int& xref = x; // declare a reference
    //int* xptr; // delcare a pointer
    //xptr = &x; // assign xprt to the memory address of x;
    //std::cout << *xptr; // derefence ( get what is at the memory address )

    // new and delete
    //int* xptr = new int(5);
    //std::cout << xptr << std::endl; // xptr contains the memory address of the int on the heap
    //*xptr = 10;
    //std::cout << *xptr << std::endl; // access what pointer is pointing at
    //delete xptr; //0x0000017691ec6bc0

    //std::cout << *xptr; // shouldn't use pointer after you delete what it was pointing to

    //Person person; // person created on stack;
    //char buffer[32] = "Jason";
    //person.SetName("jason");
    //person.SetName("Tom");
    //std::cout << person.name;
    //delete[] person.name; // clean up our newed array

    // vector
    //std::vector<int> intvector;
    //for (int i = 0; i < 10; i++)
    //{
    //    intvector.push_back(i); // push back an int into the vector
    //}
    //for (int i = 0; i < intvector.size(); i++)
    //{
    //    std::cout << intvector[i] << std::endl;
    //}

    // scope
   /* {
        int x = 5;
    }*/
    //x = 10; // outside of scope - will not compile

    //// arrays
    //int array1[10];
    //// array1 = &array1[0]
    //std::cout << array1; // prints the memory address of the first element
    

    // namespace / :: - header file
    Test::doSomething();

    // array of char array
    char array1[3][32] = { "Jason", "Tom", "Fred" };
    std::cout << array1[0];


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
