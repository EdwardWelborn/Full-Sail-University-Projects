#pragma once
#include <iostream>

namespace Test
{
    void doSomething()
    {
        std::cout << "Hello" << std::endl;
    }
}
