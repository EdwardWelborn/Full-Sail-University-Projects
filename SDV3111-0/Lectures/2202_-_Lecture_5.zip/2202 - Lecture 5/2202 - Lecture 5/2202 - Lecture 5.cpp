// 2202 - Lecture 5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Vehicle.h"
#include "Car.h"

//struct Vehicle
//{
//public:
//    char model[32];
//    int year;
//};

int main()
{
    // include memory leak detection
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(-1);
    _CrtDumpMemoryLeaks();

    // arrays 
    // char buffer[32];
    // buffer = &buffer[0];
    
    // struct
    /*Vehicle vehicle;
    strcpy_s(vehicle.model, "Ford");
    vehicle.year = 2000;
    std::cout << vehicle.model << std::endl;
    std::cout << vehicle.year << std::endl;*/

    // class Vehicle
    /*Vehicle vehicle;
    vehicle.setModel("Ford");
    vehicle.setYear(2000);
    vehicle.Print();*/

    //class Car
    Car car;
    car.setModel("Chevy"); // call bas class method
    car.setYear(2010);
    car.setTires(6);
    car.Print();

    // delete and delete[]
    int* intptr = new int();
    delete intptr;

    int* arrayptr = new int[5];
    for (int i = 0; i < 5; i++)
    {
        arrayptr[i] = i;
    }

    for (int i = 0; i < 5; i++)
    {
        std::cout << arrayptr[i];
    }
    delete[] arrayptr;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
