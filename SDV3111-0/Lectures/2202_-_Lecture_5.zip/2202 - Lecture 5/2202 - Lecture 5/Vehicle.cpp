#include "Vehicle.h"
#include <iostream>


Vehicle::Vehicle()
{
	std::cout << "Vehicle constructor" << std::endl;
	setModel("Toyota");
	setYear(2000);
}


Vehicle::~Vehicle()
{
	std::cout << "Vehicle destructor" << std::endl;
	delete year;
}

void Vehicle::setModel(const char* _model) // implementation of the function
{
	strcpy_s(model, _model);
}


char* Vehicle::getModel()
{
	return model;
}


void Vehicle::setYear(int _year)
{
	*year = _year;
}

int Vehicle::getYear()
{
	return *year;
}


void Vehicle::Print()
{
	std::cout << model << std::endl;
	std::cout << getYear() << std::endl;
}
