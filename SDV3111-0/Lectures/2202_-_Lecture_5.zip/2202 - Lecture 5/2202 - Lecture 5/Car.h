#pragma once
#include "Vehicle.h"
class Car : public Vehicle
{
private:
	int tires = 4; // by defualt 4 tires
public:
	// constructor
	Car();
	// destructor
	~Car();
	// getters and settter
	void setTires(int _tires);
	int getTires();

	void Print(); // overrride the Print in the base class
};

