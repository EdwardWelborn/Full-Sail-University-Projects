// 2202 - Lecture 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// struct
struct Person
{
    char name[32];
    int age;
};

void funcByCopy(int _x); // prototype
void funcByReference(int& _x); // prototype
void funcByPointer(int* xptr); // prototype

// struct functions
void funcByCopy(Person _person); // prototype
void funcByReference(Person& _person); // prototype
void funcByPointer(Person* personptr); // prototype
Person func(Person _person); // return value

int main()
{

    // pass to function by copy
   /* int x = 10;
    funcByCopy(x);
    std::cout << "x = " << x;*/

    // reference
    //int x = 10;
    //funcByReference(x); // 0x0079fa08 - memory address will be different each time you run the program
    //std::cout << "x = " << x;

    // pointer
    //int x = 10;
    //int* xptr = &x; // address of operator
    //std::cout << "x = " << x << " xptr = " << xptr;
    //// dereference 
    //int y = *xptr;
    //std::cout << " y = " << y;

    // function by pointer
    //int x = 10;
    //funcByPointer(&x); //0x0064fbbc
    //std::cout << "x = " << x;

    // structs
    //Person person;
    ////int sizeofPerson = sizeof(Person); // sizeof tells how many bytes variable is
    ////std::cout << sizeofPerson;
    //strcpy_s(person.name, "Jason");
    //person.age = 25;

    //std::cout << "person.name = " << person.name << std::endl;
    //std::cout << "person.age = " << person.age << std::endl;

    // structs  with functions
  /*  Person person;
    strcpy_s(person.name, "Jason");
    person.age = 25;
    funcByCopy(person);
    std::cout << "person.name = " << person.name << std::endl;
    std::cout << "person.age = " << person.age << std::endl;*/

    //Person person;
    //strcpy_s(person.name, "Jason");
    //person.age = 25;
    //funcByReference(person); // 0x003dfa8c
    //std::cout << "person.name = " << person.name << std::endl;
    //std::cout << "person.age = " << person.age << std::endl;

    /*Person person;
    strcpy_s(person.name, "Jason");
    person.age = 25;
    person = func(person);
    std::cout << "person.name = " << person.name << std::endl;
    std::cout << "person.age = " << person.age << std::endl;*/

    int size;
    //std::cin >> size;
    //int array[size]; // can't do this - can't have variable size array on the stack
    //int* array = new int[size];
    int array[4] = { 0,1,2,3 };
    //array = &array[0];
    std::cout << array << std::endl;
    int* arrayptr = array;
    std::cout << *arrayptr << std::endl;
    std::cout << array[0] << std::endl;
    std::cout << &array[0] << std::endl;



}

void funcByCopy(int _x) // int _x = x;
{
    _x = _x + 3;
}

void funcByReference(int& _x) // int& _x = x;
{
    _x = _x + 3; // 0x0079fa08
}


void funcByPointer(int* xptr) // int* xptr = &x
{
    *xptr = *xptr + 3;
}


// struct functions
void funcByCopy(Person _person)
{
    strcpy_s(_person.name, "Tom");
    _person.age = 20;
}

void funcByReference(Person& _person)
{
    strcpy_s(_person.name, "Tom");
    _person.age = 20;
}

void funcByPointer(Person* personptr)
{
    strcpy_s((*personptr).name, "Tom");
    (*personptr).age = 20;
    personptr->age = 20; // equavalent to above - indirect membership operator
}


Person func(Person _person) // return value
{
    strcpy_s(_person.name, "Tom");
    _person.age = 20;
    return _person;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
