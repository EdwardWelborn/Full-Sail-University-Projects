// 2203 Lecture 1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

void DoSomething(); // function declaration

int main()
{
    // be careful of if statement
    //int x = 5;
    //if (x = 10)  // you probably don't want to do assign here
    //{
    //    std::cout << "it is 10";
    //}

    // don't forget breaks
  /*  int x = 5;
    switch (x)
    {
    case 5:
    {
        int y = 6;
        std::cout << "It is 5";
        break;
    }
    case 6:
    {
        std::cout << "It is 6";
    }
    }*/

    //enum Color{Red, Green, Blue};
    //Color color = Color::Red;
    //std::cout << color << std::endl;
    //switch (color)
    //{
    //case Color::Red:
    //{
    //    std::cout << "Red";
    //    break;
    //}
    //case Color::Green:
    //{
    //    std::cout << "Green";
    //    break;
    //}
    //case Color::Blue:
    //{
    //    std::cout << "Blue";
    //    break;
    //}
    //}

    //DoSomething();

    //Console output
   /* float x = 5.5;
    std::cout << "x = " << x << std::endl;*/

    //int array1[5];
    //for (int i = 0; i < 5; i++)
    //{
    //    array1[i] = i;
    //}
    ////std::cout << array1 << std::endl; // can't print non char array like this.
    //// this will just print out the memory address of the array
    //for (int i = 0; i < 5; i++)
    //{
    //    std::cout << array1[i] << std::endl;
    //}

    //char buffer[5] = "Jason"; // need an additional character for the null terminator
    //char buffer[6] = "Jason";
    ////buffer[5] = 'H';
    //std::cout << buffer << std::endl;

    // Console input
    //int x;
    //std::cin >> x;
    //// todo:: while loop and do cin until i don't fail
    //if (std::cin.fail())
    //{
    //    std::cin.clear(); // clears any error flags
    //    std::cin.ignore(INT_MAX, '\n'); // flushes out stuff stuck in the buffer
    //}
    //std::cout << x << std::endl;

    //int y;
    //std::cin >> y;
    //std::cout << y << std::endl;

    //char buffer[32];
    //std::cin >> buffer;
    //std::cout << buffer << std::endl;

    //char buffer2[32];
    //std::cin >> buffer2;
    //std::cout << buffer2 << std::endl;

    // getline
    /*char buffer[6];
    std::cin.getline(buffer, 6);
    std::cout << buffer << std::endl;

    if (std::cin.fail())
    {
        std::cin.clear();
        std::cin.ignore(INT_MAX, '\n');
    }

    char buffer2[32];
    std::cin >> buffer2;
    std::cout << buffer2 << std::endl;*/

    // LAB
    //std::cout << SHRT_MAX; 

    // random
    //srand(time(NULL)); // seed the random ( only need to do this once )
    //int x = rand(); // this will get a random number;
    //std::cout << x << std::endl;
    //int y = rand();
    //std::cout << y << std::endl;

    int easy = rand() % 10;
    int medium = rand() % 10 + 15;

}

void DoSomething() // function implementation
{
    std::cout << "Hello" << std::endl;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
