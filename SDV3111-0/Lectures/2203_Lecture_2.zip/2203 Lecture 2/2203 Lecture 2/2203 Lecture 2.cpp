// 2203 Lecture 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <bitset>
#include "Console.h"

unsigned int bitField = 0;

void Print(unsigned int num); // declaration of funciton
//void Print(unsigned char num); // declaration of funciton

int main()
{
    /*char x = 'J';
    Print(x);*/

   /* int x = INT_MIN + 7;
    Print(x);*/

    //int x = 0b0001011; // enter number as binary
    //Print(x);

    //int x = 0xF369; // enter number as hexadecimal
    ////  1111 0011 0110 1001
    //Print(x);

    ////left shift ( << )
    //int x = 59;
    //Print(x);
    //x = x << 1;
    //Print(x);

    ////right shift ( >> )
    //int x = 59;
    //Print(x);
    //x = x >> 1;
    //Print(x);

    // not (~)
    /*int x = 59;
    Print(x);
    x = ~x;
    Print(x);
    x = UINT32_MAX - 59;
    Print(x);*/

    //// AND ( & )
    //int x = 149;
    //Print(x);
    //int y = 63;
    //Print(y);
    //int z = x & y;
    //Print(z);

    //// OR ( | )
    //int x = 149;
    //Print(x);
    //int y = 63;
    //Print(y);
    //int z = x | y;
    //Print(z);

    //// XOR ( ^ )
    //int x = 149;
    //Print(x);
    //int y = 63;
    //Print(y);
    //int z = x ^ y;
    //Print(z);

    //// application of bit wise operators
    //const unsigned char isHungry =  1 << 0; // 0000 0001
    //const unsigned char isSad =     1 << 1; // 0000 0010
    //const unsigned char isMad =     1 << 2; // 0000 0100
    //const unsigned char isHappy =   1 << 3; // 0000 1000
    //const unsigned char isLaughing =1 << 4; // 0001 0000
    //const unsigned char isAsleep =  1 << 5; // 0010 0000
    //const unsigned char isDead =    1 << 6; // 0100 0000
    //const unsigned char isCrying =  1 << 7; // 1000 0000

    //unsigned char me = 0; // all flags/options turned off to start

    //me = me | isHappy | isLaughing; // I am happy and laughing
    //Print(me);
    //// me |= 0000 1000 | 0001 0000
    //// me = 0001 1000
    //me = me & ~isLaughing; // I am no longer laughing
    //// me = 0001 1000 & 1110 1111
    //// me = 0000 1000
    //Print(me);

    //// Query a few states (we'll use static_cast<bool> to interpret the results as a 
    ////boolean value rather than an integer)
    //std::cout << "I am happy? " << static_cast<bool>(me & isHappy) << '\n';
    //std::cout << "I am laughing? " << static_cast<bool>(me & isLaughing) << '\n';

    // Console
    System::Console::SetCursorPosition(1, 3);
    std::cout << "Hello";

}

void Print(unsigned int num)
{
    std::cout << "DEC = " << std::dec << num << '\t';
    std::cout << "HEX = " << std::hex << num << '\t';
    std::cout << "BIN = " << std::bitset<32>(num) << std::endl;
}
//
//void Print(unsigned char num)
//{
//    std::cout << "DEC = " << std::dec << (int)num << '\t';
//    std::cout << "HEX = " << std::hex << (int)num << '\t';
//    std::cout << "BIN = " << std::bitset<32>(num) << std::endl;
//}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
