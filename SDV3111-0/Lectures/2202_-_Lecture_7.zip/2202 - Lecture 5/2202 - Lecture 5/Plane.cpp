#include "Plane.h"
#include <iostream>


Plane::Plane()
{
	setModel("Cessna");
	setYear(2022);
}
void Plane::Print()
{
	Vehicle::Print(); // call base class Print function
	std::cout << wings << std::endl;
}
