#include "Car.h"
#include <iostream>


Car::Car()
{
	setModel("Toyota");
	setYear(2000);
	//std::cout << "Car constructor" << std::endl;

}
Car::~Car()
{
	//std::cout << "Car destructor" << std::endl;
}
void Car::setTires(int _tires)
{
	tires = _tires;
}
int Car::getTires()
{
	return tires;
}

void Car::Print()
{
	//std::cout << model << std::endl; // can't access private member in base class
	//std::cout << year << std::endl; // can access protested member from base class
	Vehicle::Print(); // call base class Print function
	std::cout << tires << std::endl;
}
