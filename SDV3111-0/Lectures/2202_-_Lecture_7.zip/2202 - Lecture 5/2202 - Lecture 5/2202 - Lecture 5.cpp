// 2202 - Lecture 5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <vector>
#include "Vehicle.h"
#include "Car.h"
#include "Plane.h"

void func(Car _car) // _car = car 
{
    _car.setModel("Test"); // {model = 0x000001be5aac1660 "Toyota" year = 2000 }
}

int main()
{
    // include memory leak detection
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    _CrtSetBreakAlloc(-1);
    _CrtDumpMemoryLeaks();

    // without virtual functions
   /* std::vector<Car> cars;
    Car car;
    for (int i = 0; i < 5; i++)
    {
        cars.push_back(car);
    }
    for (int i = 0; i < cars.size(); i++)
    {
        cars[i].Print();
    }

    std::vector<Plane> planes;
    Plane plane;
    for (int i = 0; i < 5; i++)
    {
        planes.push_back(plane);
    }
    for (int i = 0; i < planes.size(); i++)
    {
        planes[i].Print();
    }*/

    //std::vector<Vehicle*> vehicles;
    //vehicles.push_back(new Car());
    //vehicles.push_back(new Plane());
    //vehicles.push_back(new Car());
    //for (int i = 0; i < vehicles.size(); i++)
    //{
    //    vehicles[i]->Print();
    //    //(*vehicles[i]).Print(); // same as above line
    //}

    //// clean up memory
    //for (int i = 0; i < vehicles.size(); i++)
    //{
    //    delete vehicles[i];
    //}

    //Vehicle vehicle;
    //vehicle.Print();
    //Vehicle vehicle2;
    //vehicle2.setModel("Car");

    //// default operator
    //vehicle = vehicle2; //{model=0x000002168f915240 "Car" year=-1 }
    //// vehicle.model = vehicle2.model
    //// vehicle.year = vehicle2.year
    //vehicle.setModel("Plane");
    //vehicle.Print();
    //vehicle2.Print();

    // assignment operator
    //Car car1;
    //Car car2;
    //car1 = car2; // this is overloaded now and does a deep copy
    //car1.setModel("Ford");
    //car1.Print();
    //car2.Print();

    // copy constructor
    Car car;
    func(car); //{model = 0x000001be5aac1660 "Toyota" year = 2000 }
                        //0x000001be5aac1660
    car.Print();


    

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
