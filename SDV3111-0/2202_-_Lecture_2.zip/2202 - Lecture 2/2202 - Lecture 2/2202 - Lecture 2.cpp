// 2202 - Lecture 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <bitset>
#include "Console.h"

void Print(unsigned int x); // prototype of function

unsigned int bitField = 0;

int main()
{
    // left shift ( << )
  /*unsigned char x = 149;
    Print(x);
    x = x << 1;
    Print(x);*/

    // right shift ( >> )
   /* unsigned char x = 149;
    Print(x);
    x = x >> 3;
    Print(x);*/

    // not operator ( ~ ) - operates on extire variable
    /*unsigned int x = 149;
    Print(x);
    x = ~x;
    Print(x);*/

    // AND ( & )
  /*  int x = 149;
    Print(x);
    int y = 63;
    Print(y);
    int z = x & y;
    Print(z);*/

    // let a be any bit
    // a & 1 = a
    // a & 0 = 

    // OR ( | )
   /* int x = 149;
    Print(x);
    int y = 63;
    Print(y);
    int z = x | y;
    Print(z);*/

    // XOR ( ^ )
    /*int x = 149;
    Print(x);
    int y = 63;
    Print(y);
    int z = x ^ y;
    Print(z);*/

    //// example of bit flags
    //const unsigned char isHungry =  1 << 0; // 0000 0001
    //const unsigned char isSad =     1 << 1; // 0000 0010
    //const unsigned char isMad =     1 << 2; // 0000 0100
    //const unsigned char isHappy =   1 << 3; // 0000 1000
    //const unsigned char isLaughing =1 << 4; // 0001 0000
    //const unsigned char isAsleep =  1 << 5; // 0010 0000
    //const unsigned char isDead =    1 << 6; // 0100 0000
    //const unsigned char isCrying =  1 << 7; // 1000 0000
    //
    //unsigned char me = 0; // all flags/options turned off to start

    //me = me | isHappy | isLaughing; // I am happy and laughing
    //Print(me);
    //me = me & (~isLaughing); // I am no longer laughing
    //Print(me);

    //// Query a few states (we'll use static_cast<bool> to interpret the results as a 
    ////boolean value rather than an integer)
    //std::cout << "I am happy? " << static_cast<bool>(me & isHappy) << '\n';
    //std::cout << "I am laughing? " << static_cast<bool>(me & isLaughing) << '\n';

    // LAB 2
    // don't do this
    bitField | 1;
    // need to store the result
    bitField = bitField | 1;


    // using Console
    System::Console::BackgroundColor(System::DarkBlue);
    System::Console::SetCursorPosition(1, 4);
    std::cout << "Hello";

    // clear the console
    system("cls");


}

void Print(unsigned int x) // implementation
{
    std::cout << "DEC = " << std::dec << x << '\t';
    std::cout << "HEX = " << std::hex << x << '\t';
    std::cout << "BIN = " << std::bitset<32>(x) << std::endl;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
