﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient; 

namespace Lab9_UserProject
{
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start\n");

            // MySQL Database Connection String
            //           string cs = @"server=192.168.1.19;userid=EdwardWelborn;password=password;database=example0219;port=8889";

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            string connection = @"server=192.168.1.13;userid=EdwardWelborn;password=password;database=example0219;port=8889";

            try
            {
                MySqlConnection dbconn = new MySqlConnection(connection);
                dbconn.Open();
                Console.Write("Please Input Your UserName: ");
                string inputUserName = Console.ReadLine();

                Console.Write("Please Input Your Password: ");
                string inputPassword = Console.ReadLine();

                User myUser = new User();

                bool correctLogin = myUser.Login(dbconn, inputUserName, inputPassword);
                if (correctLogin)
                {
                    Console.Write("Add an Email?: (Y/N)");
                    string inputAnswer = Console.ReadLine();
                    bool Answer;
                    bool.TryParse(inputAnswer.ToUpper(), out Answer);
                    if (Answer)
                    {
                        Console.Write("Please type the email: ");
                        string inputNewEmail = Console.ReadLine():
                        Console.Write("Personal or Corporate Email: (1 or 2): ";
                        string inputNewEmailType = Console.ReadLine();
                        myUser.ChangeEmail(dbconn, inputNewEmail, inputNewEmailType);
                    }
                    
                } 



            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            Console.WriteLine("Done");
            Console.ReadKey();
        }
    }
}