﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Lab9_UserProject
{
    class User
    {
        public string userId;
        public string firstname;
        public string lastname;
        public DateTime dob;
        public string gender;
        public int occupationId;
        public User()
        {
            Console.WriteLine("New User Created");
        }
        public void Display()
        {
            Console.WriteLine($"UserID: {userId}, Firstname: {firstname}, Lastname: {lastname}, DOB: {dob}, Gender: {gender}, OccupationId: {occupationId}");
        }
        public bool Login(MySqlConnection conn, string userName, string Password)
        {
            string stm = "Select userId, firstname, lastname, dob, gender, occupationId from users where username = @username AND passwordEncrypted = MD5(password)";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@username", userName);
            cmd.Parameters.AddWithValue("@password", Password);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                userId = rdr["userID"].ToString();
                firstname = rdr["firstname"].ToString();
                lastname = rdr["lastname"].ToString();
                DateTime birthdate;
                DateTime.TryParse(rdr["dob"].ToString(), out birthdate);
                dob = birthdate;
                gender = rdr["gender"].ToString();
                int occ;
                int.TryParse(rdr["occupationId"].ToString(), out occ);
                occupationId = occ;

                rdr.Close();
                Console.WriteLine("Login Successful");
                bool correctLogin = true;
                return correctLogin;
            }
            else
            {
                Console.WriteLine("Invalid Login");
                bool correctLogin = False;
                return correctLogin;
            }
        }
        public void ChangePassword(MySqlConnection conn, string NewPassword)
        {
            string stm = "Update users set password = @password, passwordEncrypted = MD5(@password) where userId = @userId;";

            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", this.userId);
            cmd.Parameters.AddWithValue("@password", NewPassword);
            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Close();
            Console.WriteLine("Password Changed");
        }
        public void ChangeEmail(MySqlConnection conn, string NewEmail, string newEmailType)
        {
            string stm = "Update userEmail set userEmail = @newEmail, userEmailTypeId = @newEmailType where userId = @userId;";

            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", this.userId);
            cmd.Parameters.AddWithValue("@newEmail", NewEmail);
            cmd.Parameters.AddWithValue("@newEmailType", newEmailType);
            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Close();
            Console.WriteLine("Email Added");
        }
    }
}
