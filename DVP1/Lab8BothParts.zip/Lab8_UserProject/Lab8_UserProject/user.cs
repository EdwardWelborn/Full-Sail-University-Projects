﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DBS_Login
{
    class User
    {
        public string userId;
        public string firstname;
        public string lastname;
        public DateTime dob;
        public string gender;
        public int occupationId;
        public User()
        {
           // Console.WriteLine("New User Created");
        }
        public void Display()
        {
            Console.WriteLine($"UserID: {userId}, Firstname: {firstname}, Lastname: {lastname}, DOB: {dob}, Gender: {gender}, OccupationId: {occupationId}");
        }
        public void Login(MySqlConnection conn, string userName, string Password)
        {
            string stm = "Select userId, firstname, lastname, dob, gender, occupationId from users where username = @username AND passwordEncrypted = MD5(password)";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@username", userName);
            cmd.Parameters.AddWithValue("@password", Password);
            MySqlDataReader rdr = cmd.ExecuteReader();
            string userId = rdr["userId"].ToString();
            string firstname = rdr["firstname"].ToString();
            if (rdr.HasRows)
            {
                rdr.Read();
                userId = rdr["userID"].ToString();
                firstname = rdr["firstname"].ToString();
                lastname = rdr["lastname"].ToString();
                DateTime birthdate;
                DateTime.TryParse(rdr["dob"].ToString(), out birthdate);
                dob = birthdate;
                gender = rdr["gender"].ToString();
                int occ;
                int.TryParse(rdr["occupationId"].ToString(), out occ);
                occupationId = occ;

                rdr.Close();
                Console.WriteLine("Login Successful");

            }
        }
        public void ChangePassword(MySqlConnection conn, string NewPassword)
        {
            string stm = "Update users set password = @password, passwordEncrypted = MD5(@password) where userId = @userId;";

            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", this.userId);
            cmd.Parameters.AddWithValue("@password", NewPassword);
            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Close();
            Console.WriteLine("Password Changed");
        }
        public void Info(MySqlConnection conn, string userID)
        {
            string stm = "select CONCAT(users.firstname, ' ', users.lastname) as fullname, occupation.occupation from users " +
                         "join occupation on users.occupationID = occupation.occupationId " +
                         "where userID = @userID;";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", userID);

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string fullname = rdr["fullname"].ToString();
            string occupation = rdr["occupation"].ToString();

            Console.WriteLine("Fullname: {0}, Occupation: {1}", fullname, occupation);
               
            rdr.Close();
        }

        public void OrderInfo(MySqlConnection conn, string userID)
        {
            string stm = "select users.userID, count(orderItem.orderId) as OrderInfo " +
                         "from users " +
                         "join orders on orders.userId = users.userId " +
                         "join orderitem on orderItem.OrderId = orders.orderId " +
                         "where users.userID = @userId " +
                         "group by orders.orderId; ";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", userID);

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string userId = rdr["userId"].ToString();
            string orderInfo = rdr["OrderInfo"].ToString();

            Console.WriteLine("UserID: {0}, OrderInfo: {1}", userID, orderInfo);
            rdr.Close();

        }

        public void DVDCount(MySqlConnection conn, string userID)
        {
            string stm = "select users.userID, count(userDVD.`userDvdId`) as DVDInfo " +
                         "from users " +
                         "join UserDvd on userDvd.userId = users.userId " +
                         "join dvd on dvd.dvdId = userDVD.`dvdId` " +
                         "where users.userID = @userID " +
                         "group by userId;";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", userID);

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string userId = rdr["userId"].ToString();
            string DVDInfo = rdr["DVDInfo"].ToString();

            Console.WriteLine("UserID: {0}, DVDInfo: {1}", userID, DVDInfo);
            rdr.Close();

        }

        public void VehicleCount(MySqlConnection conn, string userID)
        {
            string stm = "select users.userID, count(userVehicle.vehicleId) as VehicleInfo " +
                         "from users " +
                         "join UserVehicle on userVehicle.userId = users.userId " +
                         "join vehicle on vehicle.vehicleId = userVehicle.vehicleId " +
                         "where users.userID = @userId " +
                         "group by userId;";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", userID);

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string userId = rdr["userId"].ToString();
            string VehicleInfo = rdr["VehicleInfo"].ToString();

            Console.WriteLine("UserID: {0}, VehicleInfo: {1}", userID, VehicleInfo);
            rdr.Close();

        }
    }
}
