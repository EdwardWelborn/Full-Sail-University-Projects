﻿// DEV-231
// Objective: Test your connection from C# on a Windows VMWare instance to MySQL on a Macbook
// This code will connect to MySQL and display the version.
// Be sure both VMWare/Windows and MAMP is running

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Lab8_OrderProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start\n");

            // MySQL Database Connection String
            //           string cs = @"server=192.168.1.19;userid=EdwardWelborn;password=password;database=example0219;port=8889";

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            string connection = @"server=192.168.1.13;userid=EdwardWelborn;password=password;database=example0219;port=8889";

            try
            {
                MySqlConnection dbconn = new MySqlConnection(connection);
                dbconn.Open();
                Console.Write("Please input a New ItemId: ");
                string inputItemId = Console.ReadLine();
                Console.Write("Please Input a Quantity: ");
                string inputQuantity = Console.ReadLine();

                Orders myOrders = new Orders();

                myOrders.AddItem(dbconn, inputItemId, inputQuantity);


            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
            Console.WriteLine("Done");
            Console.ReadKey();
        }
    }
}
