﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Lab8_OrderProject
{
    class Orders
    {
        public string userId;
        public string firstname;
        public string lastname;
        public DateTime dob;
        public string gender;
        public int occupationId;
        public Orders()
        {
            
        }

        public void Login(MySqlConnection conn, string userName, string Password)
        {
            string stm = "Select userId, firstname, lastname, dob, gender, occupationId from users where username = @username AND passwordEncrypted = MD5(password)";
            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@username", userName);
            cmd.Parameters.AddWithValue("@password", Password);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                userId = rdr["userID"].ToString();
                firstname = rdr["firstname"].ToString();
                lastname = rdr["lastname"].ToString();
                DateTime birthdate;
                DateTime.TryParse(rdr["dob"].ToString(), out birthdate);
                dob = birthdate;
                gender = rdr["gender"].ToString();
                int occ;
                int.TryParse(rdr["occupationId"].ToString(), out occ);
                occupationId = occ;

                rdr.Close();
                Console.WriteLine("Login Successful");

            }
        }
        public void ChangePassword(MySqlConnection conn, string NewPassword)
        {
            string stm = "Update users set password = @password, passwordEncrypted = MD5(@password) where userId = @userId;";

            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@userId", this.userId);
            cmd.Parameters.AddWithValue("@password", NewPassword);
            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Close();
            Console.WriteLine("Password Changed");
        }

        public void AddItem(MySqlConnection conn, string ItemID, String Quantity)
        {
            string stm = "select item.itemid, item.retailPrice " +
                         "from Item " +
                         "where item.itemId = @ItemID; ";

            MySqlCommand cmd = new MySqlCommand(stm, conn);
            cmd.Parameters.AddWithValue("@ItemID", ItemID);
            cmd.Parameters.AddWithValue("@Quantity", Quantity);
            MySqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                ItemID = rdr["ItemID"].ToString();
                string retailPrice = rdr["retailPrice"].ToString();
                decimal Price;
                decimal.TryParse(retailPrice, out Price);
                decimal Quant;
                decimal.TryParse(Quantity, out Quant);
                decimal totalPrice = Quant * Price;
                rdr.Close();
                Console.WriteLine("ItemID: {0}, Retail Price: {1}", ItemID, totalPrice);
            }
            else Console.WriteLine("Item Not Found");
        }
    }
}
