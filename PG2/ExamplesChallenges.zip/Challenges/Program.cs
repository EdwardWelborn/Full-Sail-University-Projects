﻿using System;

namespace Challenges
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] options = new string[]
            {
                "1. Draw Challenge 1",
                "2. Draw Challenge 2",
                "3. Draw Challenge 3",
                "4. Draw Challenge 4",
                "5. Draw Challenge 5",
                "6. Exit"
            };
            bool continueLoop = true;
            do
            {
                Console.Clear();
                for (int i = 0; i < options.Length; i++)
                {
                    Console.WriteLine(options[i]);
                }
                Console.Write("Choice? ");
                string selection = Console.ReadLine();
                bool success = int.TryParse(selection, out int choice);
                if(success)
                {
                    switch (choice)
                    {
                        case 1:
                            //Console.WriteLine($"{options[0]}");
                            DrawChallenge1();
                            break;
                        case 2:
                            Console.WriteLine($"{options[1]}");
                            DrawChallenge2();
                            break;
                        case 3:
                            Console.WriteLine($"{options[2]}");
                            DrawChallenge3();
                            break;
                        case 4:
                            Console.WriteLine($"{options[3]}");
                            DrawChallenge4();
                            break;
                        case 5:
                            Console.WriteLine($"{options[4]}");
                            DrawChallenge5();
                            break;
                        case 6:
                            Console.WriteLine($"{options[5]}");
                            continueLoop = false;
                            break;
                        default:
                            break;
                    }
                }
                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
            } while (continueLoop);
        }

        static void DrawChallenge1()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(' ');
            Console.ResetColor();
        }
        static void DrawChallenge2()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(new string(' ', 15));
            Console.ResetColor();
        }
        static void DrawChallenge3()
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Green;
            Random rando = new Random();
            int size = rando.Next(1, Console.WindowWidth);
            Console.Write(new string(' ', size));
            Console.ResetColor();
        }
        static void DrawChallenge4()
        {
            Console.Clear();
            Random rando = new Random();
            Console.BackgroundColor = (ConsoleColor)rando.Next(16);
            int size = rando.Next(1, Console.WindowWidth);
            Console.Write(new string(' ', size));
            Console.ResetColor();
        }
        static void DrawChallenge5()
        {
            Console.Clear();
            Random rando = new Random();
            Console.BackgroundColor = (ConsoleColor)rando.Next(16);
            int size = rando.Next(1, Console.WindowWidth);
            int row = rando.Next(0, Console.WindowHeight);

            Console.SetCursorPosition(0, row);
            //OR
            Console.CursorTop = row;

            Console.Write(new string(' ', size));
            Console.ResetColor();
        }
    }
}
