﻿using System;

namespace Output
{
    class Program
    {
        static void Main(string[] args)
        {
            int width = Console.WindowWidth;
            int height = Console.WindowHeight;

            Console.CursorLeft = 10;
            Console.CursorTop = 5;
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Width: {width}\tHeight: {height}");
            Console.SetCursorPosition(20, 7);
            Console.WriteLine($"Width: {width}\tHeight: {height}");
            Console.ResetColor();
        }
    }
}
