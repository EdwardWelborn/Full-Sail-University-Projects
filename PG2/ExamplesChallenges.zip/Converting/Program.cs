﻿using System;

namespace Converting
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 5;
            double dNum = number; //implicit conversion from int to double

            number = (int)dNum;//explicit conversion from double to int

            //Parsing strings
            string ageInput = "steev";
            try
            {
                int age = int.Parse(ageInput);
                Console.WriteLine($"Age: {age}");
            }
            catch (Exception)
            {
                Console.WriteLine("That was not a number.");
            }

            bool wasANumber = int.TryParse(ageInput, out int myAge);
            if(wasANumber)
                Console.WriteLine($"Age: {myAge}");
            else
                Console.WriteLine("That was not a number either.");

        }
    }
}
