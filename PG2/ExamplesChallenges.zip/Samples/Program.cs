﻿using System;

namespace Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 10;//4 bytes
            bool flag = true;//1 byte
            char b = 'b';//2 bytes

            int[] nums = new int[] { 5, 4, 3, 2, 1 };

            string usersInput = Console.ReadLine();
            Console.WriteLine(usersInput);

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
