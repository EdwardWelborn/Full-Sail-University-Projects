﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemoProject
{
    public class TextData
    {
        private string text1;
        private string text2;
        private string text3;

        public string Text1
        {
            get
            {
                return text1;
            }

            set
            {
                text1 = value;
            }
        }

        public string Text2
        {
            get
            {
                return text2;
            }

            set
            {
                text2 = value;
            }
        }

        public string Text3
        {
            get
            {
                return text3;
            }

            set
            {
                text3 = value;
            }
        }
    }
}
