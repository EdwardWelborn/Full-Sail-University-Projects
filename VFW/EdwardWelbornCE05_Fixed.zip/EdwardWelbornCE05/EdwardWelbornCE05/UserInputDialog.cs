﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EdwardWelbornCE05
{
    public partial class UserInputDialog : Form
    {



        //public class ChangeClassArgs : EventArgs
        //{
        //    // instance member variable for image index
        //    public int intImageIndex;
        //    public string newName;
        //    public bool active;
        //    public int crewSize;

        //    // constructor assignes the index argument to the instance variable
        //    public ChangeClassArgs(int index, string name, bool activeDuty, int crewCapacity)
        //    {
        //        intImageIndex = index;
        //        newName = name;
        //        active = activeDuty;
        //        crewSize = crewCapacity;
        //    }
        //}


        //public void CatchData(object sender, ChangeClassArgs e)
        //{
        //    txtShipName.Text = e.newName;
        //    chkActiveDuty.Checked = e.active;
        //    numCrewSize.Value = e.crewSize;

        //    // check radio button based on the index
        //    switch (e.intImageIndex)
        //    {
        //        case 1:
        //        {
        //            rdoDestroyer.Checked = true;
        //        }
        //            break;
        //        case 2:
        //        {
        //            rdoCruiser.Checked = true;
        //        }
        //            break;

        //        default:
        //        {
        //            rdoFreighter.Checked = true;
        //        }
        //            break;
        //    }

        //    txtShipName.Select();
        //}

        public UserInputDialog()
        {
            InitializeComponent();
        }

        // Creates an Event delegate with EventArgs needing to modify the object
        public EventHandler<MainForm.ModifyObjectEventArgs> ModifyObject;

        //
        public EventHandler AddSpaceShipToListView;
        
        //
        public EventHandler CloseUserInputDialogForm;

        //
        public SpaceShips Data
        {
            get
            {
                //Create a new spaceship with the fields taken from the user
                SpaceShips s = new SpaceShips();
                s.Name = txtShipName.Text;
                s.CrewSize = numCrewSize.Value;
                s.Active = chkActiveDuty.Checked;
                s.Cruiser = rdoCruiser.Checked;
                s.Destroyer = rdoDestroyer.Checked;
                s.Freighter = rdoFreighter.Checked;
                return s;
            }

            set
            {
                //Use this setter when needing to reset the user input fields back to default
                txtShipName.Text = value.Name;
                numCrewSize.Value = value.CrewSize;
                chkActiveDuty.Checked = value.Active;
                rdoCruiser.Checked = value.Cruiser;
                rdoDestroyer.Checked = value.Destroyer;
                rdoFreighter.Checked = value.Freighter;
            }
        }













        //
        private void btnOk_Click(object sender, EventArgs e)
        {
            //raise the AddShipToListView event
            if (AddSpaceShipToListView != null)
            {
                AddSpaceShipToListView(this, new EventArgs());
            }
            //set the user input fields back to default
            Data = new SpaceShips();
        }

        //
        private void btnApply_Click(object sender, EventArgs e)
        {
            // Save the object back over to it's current record
            // Only visible during the doubleclick event from the main form.
            //raise the AddShipToListView event
            if (AddSpaceShipToListView != null)
            {
                AddSpaceShipToListView(this, new EventArgs());
            }
            //set the user input fields back to default
            Data = new SpaceShips();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Close the form without saving
            if (CloseUserInputDialogForm != null)
            {
                CloseUserInputDialogForm(this, new EventArgs());
            }
        }

        // Custom event handler for Selected Space Ship
        public void HandleSpaceShipSelected(object sender, EventArgs e)
        {
            
            MainForm m = sender as MainForm;
            Data = m.ListViewItemSelected as SpaceShips;
        }

        private void UserInputDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            // invoke the event handler
            //if (Change != null)
            //{
            //    txtShipName.Text = Text;
                
            //    // we need to check every radio button to see which one is selected
            //    int index = 0;
            //    if (rdoDestroyer.Checked)
            //    {
            //        index = 1;
            //    }
            //    else if (rdoCruiser.Checked)
            //    {
            //        index = 2;
            //    }

            //    // now we invoke the event handler and pass the index
            //    // as an argument for the custom event args
            //    Change(this, new ChangeClassArgs(index, txtShipName.Text, chkActiveDuty.Checked, (int) numCrewSize.Value));
            // }
        }
    }
}
